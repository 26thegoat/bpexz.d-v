import 'dotenv/config';
import { Client, GatewayIntentBits, EmbedBuilder } from 'discord.js';

const {
  DISCORD_BOT_TOKEN, DISCORD_GUILD_ID, ADMIN_ROLE_ID,
  BPEXZ_API_BASE, BOT_API_SECRET,
  SYNC_INTERVAL_MINUTES = '15',
} = process.env;

if (!DISCORD_BOT_TOKEN || !BPEXZ_API_BASE || !BOT_API_SECRET) {
  console.error('Missing required env vars. See .env.example');
  process.exit(1);
}

const api = async (path, body, method = 'POST') => {
  const res = await fetch(`${BPEXZ_API_BASE}/${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', 'x-bot-secret': BOT_API_SECRET },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
};

const isAdmin = (interaction) =>
  interaction.memberPermissions?.has('Administrator') ||
  (ADMIN_ROLE_ID && interaction.member?.roles?.cache?.has(ADMIN_ROLE_ID));

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});

client.once('ready', () => {
  console.log(`✅ Bot logged in as ${client.user.tag}`);
  // periodic role sync
  const ms = parseInt(SYNC_INTERVAL_MINUTES) * 60_000;
  setInterval(syncRoles, ms);
  syncRoles();
});

// New member auto-welcome
client.on('guildMemberAdd', async (member) => {
  try {
    const status = await api(`user-status?discord_id=${member.id}`, null, 'GET');
    if (status.has_active_plan && status.discord_role_id) {
      await member.roles.add(status.discord_role_id).catch(() => {});
    }
  } catch (e) { console.error('welcome sync failed', e); }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  const { commandName } = interaction;

  try {
    if (commandName === 'redeem') {
      await interaction.deferReply({ ephemeral: true });
      const code = interaction.options.getString('code', true).trim();
      const result = await api('redeem-code', {
        code,
        discord_id: interaction.user.id,
        discord_username: interaction.user.username,
      });
      // assign role
      if (result.discord_role_id && interaction.guild) {
        const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
        if (member) await member.roles.add(result.discord_role_id).catch(e => console.error('role add', e));
      }
      const embed = new EmbedBuilder()
        .setTitle('✅ Code redeemed')
        .setDescription(`**${result.plan_name}** is now active for **${result.duration_days} days**.`)
        .setColor(0xa855f7)
        .setFooter({ text: `Expires ${new Date(result.expires_at).toLocaleDateString()}` });
      return interaction.editReply({ embeds: [embed] });
    }

    if (commandName === 'status') {
      await interaction.deferReply({ ephemeral: true });
      const s = await api(`user-status?discord_id=${interaction.user.id}`, null, 'GET');
      const embed = new EmbedBuilder()
        .setTitle('📊 Your bpexz.dev status')
        .setColor(s.has_active_plan ? 0x22c55e : 0x6b7280)
        .addFields(
          { name: 'Plan', value: s.plan_name ?? 'None', inline: true },
          { name: 'Whitelisted', value: s.whitelisted ? 'Yes' : 'No', inline: true },
          { name: 'Expires', value: s.expires_at ? new Date(s.expires_at).toLocaleString() : '—', inline: false },
        );
      if (!s.profile_linked) embed.setFooter({ text: 'Login on bpexz.dev to link your account.' });
      return interaction.editReply({ embeds: [embed] });
    }

    if (commandName === 'gen') {
      if (!isAdmin(interaction)) return interaction.reply({ content: '❌ Admin only.', ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      const plan = interaction.options.getString('plan', true);
      const count = interaction.options.getInteger('count') ?? 1;
      const r = await api('generate-code', { plan_name: plan, count });
      return interaction.editReply({
        content: `✅ Generated ${r.codes.length} **${r.plan_name}** codes:\n\`\`\`\n${r.codes.join('\n')}\n\`\`\``,
      });
    }

    if (commandName === 'whitelist') {
      if (!isAdmin(interaction)) return interaction.reply({ content: '❌ Admin only.', ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      const sub = interaction.options.getSubcommand();
      const user = interaction.options.getUser('user', true);
      if (sub === 'add') {
        await api('whitelist-user', {
          discord_id: user.id,
          reason: interaction.options.getString('reason') ?? `By ${interaction.user.username}`,
          added_by_discord_id: interaction.user.id,
        });
        return interaction.editReply(`✅ <@${user.id}> whitelisted.`);
      } else {
        await api('whitelist-user', { discord_id: user.id, action: 'remove' });
        return interaction.editReply(`✅ <@${user.id}> removed from whitelist.`);
      }
    }
  } catch (e) {
    console.error(e);
    const msg = `❌ ${e.message}`;
    if (interaction.deferred) return interaction.editReply(msg);
    return interaction.reply({ content: msg, ephemeral: true });
  }
});

// Periodic role sync — fetch all guild members, assign/remove roles based on plan
async function syncRoles() {
  try {
    const guild = await client.guilds.fetch(DISCORD_GUILD_ID);
    const members = await guild.members.fetch();
    console.log(`🔄 Syncing roles for ${members.size} members...`);
    for (const [, member] of members) {
      if (member.user.bot) continue;
      try {
        const s = await api(`user-status?discord_id=${member.id}`, null, 'GET');
        if (s.has_active_plan && s.discord_role_id) {
          if (!member.roles.cache.has(s.discord_role_id)) {
            await member.roles.add(s.discord_role_id).catch(() => {});
          }
        }
        // remove plan roles if expired (looped through all plans by tracking known role ids would be cleaner — left as TODO)
      } catch (e) {
        // ignore individual failures
      }
    }
    console.log('✅ Role sync complete');
  } catch (e) { console.error('Role sync error:', e); }
}

client.login(DISCORD_BOT_TOKEN);
