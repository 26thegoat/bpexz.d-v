import 'dotenv/config';
import { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';

const commands = [
  new SlashCommandBuilder()
    .setName('redeem')
    .setDescription('Redeem a bpexz.dev code')
    .addStringOption(o => o.setName('code').setDescription('Your code').setRequired(true)),

  new SlashCommandBuilder()
    .setName('status')
    .setDescription('Check your bpexz.dev plan status'),

  new SlashCommandBuilder()
    .setName('gen')
    .setDescription('[Admin] Generate codes')
    .addStringOption(o => o.setName('plan').setDescription('Plan name (Basic/Pro/Elite)').setRequired(true))
    .addIntegerOption(o => o.setName('count').setDescription('How many (1-50)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName('whitelist')
    .setDescription('[Admin] Manage whitelist')
    .addSubcommand(sc => sc.setName('add').setDescription('Add user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)).addStringOption(o => o.setName('reason').setDescription('Reason')))
    .addSubcommand(sc => sc.setName('remove').setDescription('Remove user').addUserOption(o => o.setName('user').setDescription('User').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
].map(c => c.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_BOT_TOKEN);
await rest.put(
  Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, process.env.DISCORD_GUILD_ID),
  { body: commands },
);
console.log('✅ Slash commands registered.');
